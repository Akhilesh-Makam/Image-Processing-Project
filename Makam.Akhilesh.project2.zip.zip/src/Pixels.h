#pragma once
#include <iostream>
#include <vector>
#include <sstream>
#include <fstream>
using namespace std;

struct Pixel {
	unsigned char blue;
	unsigned char green;
	unsigned char red;
};
